import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { NotificationService } from 'src/app/Services/notification.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  invalidLogin: boolean | undefined;
  userForm!: FormGroup;
  public loginstarts :boolean =false;
  formErrors = {
    'email': '',
    'password': ''
  };
  validationMessages = {
    'email': {
      'required': 'Please enter your email',
      'email': 'please enter your vaild email'
    },
    'password': {
      'required': 'please enter your password',
      'pattern': 'The password must contain numbers and letters',
      'minlength': 'Please enter more than 4 characters',
      'maxlength': 'Please enter less than 25 characters',
    }
  };

  constructor(private router: Router,
              private fb: FormBuilder,
              private http: HttpClient,
              private  notificationservice : NotificationService,
              private toastr: ToastrService) {
  }

  ngOnInit() { 

   // this.notificationservice.setToasteService(this.toastr);
    // console.log("------------------------------")
    // console.log(this.toastr);
    this.buildForm();
  }

  buildForm() {
    this.userForm = this.fb.group({
      'email': ['', [
        Validators.required,
        Validators.email
      ]
      ],
      'password': ['', [
       // Validators.pattern('^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$'),
        Validators.minLength(3),
        Validators.maxLength(25)
      ]
      ],
    });
    

    this.userForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }

  onValueChanged(data?: any) {
    // if (!this.userForm) {
    //   return;
    // }
    // const form = this.userForm;
    // for (const field in this.formErrors) {
    //   if (Object.prototype.hasOwnProperty.call(this.formErrors, field)) {
    //     this.formErrors[field] = '';
    //     const control = form.get(field);
    //     if (control && control.dirty && !control.valid) {
    //       const messages = this.validationMessages[field];
    //       for (const key in control.errors) {
    //         if (Object.prototype.hasOwnProperty.call(control.errors, key)) {
    //           this.formErrors[field] += messages[key] + ' ';
    //         }
    //       }
    //     }
    //   }
    // }
  }
  login() {
    this.loginstarts=true;
    const form = this.userForm;
    

    this.http.post<any>('http://localhost:5000/api/auth/login', form.value)
    .subscribe(response => {
      const token = (<any>response).token;
      const role = (<any>response).role;
      console.log(role);
      localStorage.setItem("jwt", token);
      this.invalidLogin = false;
      this.loginstarts=false;
      this.showToasterSuccess();
      if(role=="Admin")
      {
        this.router.navigate(['/Admin/Dashboard']);
      }else if(role=="Nurse"){
        this.router.navigate(['/Nurse/Dashboard']);
      }else if(role=="Patient"){
        this.router.navigate(['/Patient/Dashboard']);
      }else if(role=="Physician"){
       this.router.navigate(['/Physician/Dashboard']);
       
      
      }
     
  }, err => {
    
   
    setTimeout(() => 
    {
      this.loginstarts=false;
      this.invalidLogin = true;
      this.showToasterError();
    },
    5000);
   
  })

   
  }
  Forgot() {
    this.router.navigate(['/ForgotPassword']);
  }
  ChangePassword() {
    this.router.navigate(['/ChangePassword']);
  }
  Registration(){

    this.router.navigate(['/Registration']);

  }
  email = new FormControl('', [Validators.required, Validators.email]);

  getErrorMessage() {
    if (this.email.hasError('required')) {
      return 'You must enter a value';
    }

    return this.email.hasError('email') ? 'Not a valid email' : '';
  }

  showToasterSuccess(){
    this.notificationservice.showSuccess("Login Sucessfully!!!", "Login")
}

showToasterError(){
    
    this.notificationservice.showError("Invalid user name or password", "Invalid Login")
}


}